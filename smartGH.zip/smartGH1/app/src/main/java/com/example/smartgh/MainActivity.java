package com.example.smartgh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smartgh.main_menu_s.Amount_of_sunlight;
import com.example.smartgh.main_menu_s.Biokdo;
import com.example.smartgh.main_menu_s.Humidity;
import com.example.smartgh.main_menu_s.Plant_list;
import com.example.smartgh.main_menu_s.Temperature;
import com.example.smartgh.ui.Atomizer;
import com.example.smartgh.ui.BTService;
import com.example.smartgh.ui.Bluetooth;
import com.example.smartgh.ui.Fan;
import com.example.smartgh.ui.Led;
import com.example.smartgh.ui.WaterTank;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {


    private ImageView btn_temp1, btn_humidity1, btn_amount_of_sunlight1, btn_biokdo1, btn_plant_move, btn_left_menu;

//지울것들





    private BluetoothSocket mBTSocket = null; // bi-directional client-to-client data path

    private static final UUID BTMODULEUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); // "random" unique identifie
    private ArrayAdapter<String> mBTArrayAdapter;





    // UI-Bluetooth
    private TextView bluetooth_name;
    private BluetoothAdapter mBTAdapter;
    private static final int CONNECTING_STATUS = 3;
    private static final int MESSAGE_READ = 2;
    private static final int REQUEST_ENABLE_BT = 1;
    private ConnectedThread mConnectedThread;
    private Handler mHandler;

    //
    private DrawerLayout drawerLayout;
    private View drawerView;
    private View view;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mBTAdapter = BluetoothAdapter.getDefaultAdapter();
        mHandler = getConnection_failed();
        mBTArrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);


        if (mBTArrayAdapter == null){

        }
        else{
            btn_temp1 = findViewById(R.id.btn_temp1);
            btn_temp1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Toast.makeText(getApplicationContext(), "ON", Toast.LENGTH_SHORT).show();

                   Intent intent = new Intent(MainActivity.this, BTService.class);
                   startService(intent);


                    if (mConnectedThread != null) //First check to make sure thread created
                        mConnectedThread.write("a"); //a라는 값때문에 아두이노에서 움직임
                }
            });

        }

        btn_humidity1 = findViewById(R.id.btn_humidity1);
        btn_humidity1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Bluetooth.class);
                startActivity(intent);
            }
        });

        btn_amount_of_sunlight1 = findViewById(R.id.btn_amount_of_sunlight1);
        btn_amount_of_sunlight1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Amount_of_sunlight.class);
                startActivity(intent);
            }
        });
        btn_biokdo1 = findViewById(R.id.btn_biokdo1);
        btn_biokdo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Biokdo.class);
                startActivity(intent);
            }
        });
        btn_plant_move = findViewById(R.id.btn_plant_move);
        btn_plant_move.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Plant_list.class);
                startActivity(intent);
            }
        });
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawerView = (View) findViewById(R.id.drawer1);

        btn_left_menu = (ImageView) findViewById(R.id.btn_left_menu);
        btn_left_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(drawerView);
            }
        });

        ImageView btn_bluetooth = (ImageView) findViewById(R.id.btn_bluetooth);
        btn_bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Bluetooth.class);
                startActivity(intent); //액티비티 이동
            }
        });
        Button btn_led = (Button) findViewById(R.id.btn_led);
        btn_led.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Led.class);
                startActivity(intent); //액티비티 이동
            }
        });

        Button btn_fan = (Button) findViewById(R.id.btn_fan);
        btn_fan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Fan.class);
                startActivity(intent); //액티비티 이동
            }
        });

        Button btn_atomizer = (Button) findViewById(R.id.btn_atomizer);
        btn_atomizer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Atomizer.class);
                startActivity(intent); //액티비티 이동
            }
        });

        Button btn_waterTank = (Button) findViewById(R.id.btn_waterTank);
        btn_waterTank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, WaterTank.class);
                startActivity(intent); //액티비티 이동
            }
        });

        drawerLayout.setDrawerListener(listener);
        drawerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });

        // Intent get_intent = getIntent();
        // bluetooth_name = getIntent().getExtras();
        //  bluetooth_name.getString("test");

        Intent intent = getIntent();
        String msg = intent.getStringExtra("k");
        bluetooth_name = (TextView) findViewById(R.id.bluetooth_name);
        bluetooth_name.setText(msg);


    }

    DrawerLayout.DrawerListener listener = new DrawerLayout.DrawerListener() {
        @Override
        public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

        }

        @Override
        public void onDrawerOpened(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerClosed(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerStateChanged(int newState) {

        }
    };


    private Handler getConnection_failed() {
        return new Handler(){
            @SuppressLint("HandlerLeak")
            public void handleMessage(android.os.Message msg){
                if(msg.what == MESSAGE_READ){
                    String readMessage = null;
                    try {
                        readMessage = new String((byte[]) msg.obj, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }

                }

                if(msg.what == CONNECTING_STATUS){
                    if(msg.arg1 == 1) {


                    }


                }
            }
        };
    }


    public class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[1024];  // buffer store for the stream
            int bytes; // bytes returned from read()
            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {
                    // Read from the InputStream
                    bytes = mmInStream.available();
                    if (bytes != 0) {
                        SystemClock.sleep(100); //pause and wait for rest of data. Adjust this depending on your sending speed.
                        bytes = mmInStream.available(); // how many bytes are ready to be read?
                        bytes = mmInStream.read(buffer, 0, bytes); // record how many bytes we actually read
                        mHandler.obtainMessage(MESSAGE_READ, bytes, -1, buffer)
                                .sendToTarget(); // Send the obtained bytes to the UI activity
                    }
                } catch (IOException e) {
                    e.printStackTrace();

                    break;
                }
            }
        }
        public void write(String input) {
            byte[] bytes = input.getBytes();           //converts entered String into bytes
            try {
                mmOutStream.write(bytes);
            } catch (IOException e) { }
        }
    }
}
