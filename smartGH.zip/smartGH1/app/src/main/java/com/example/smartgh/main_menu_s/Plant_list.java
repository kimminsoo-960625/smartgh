package com.example.smartgh.main_menu_s;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.smartgh.MainActivity;
import com.example.smartgh.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;


public class Plant_list extends AppCompatActivity {

    TextView PlantName, Minimum_Plant_temp, Maximum_Plant_temp, Minimum_Plant_humi, Maximum_Plant_humi, Plant_sun, Plant_mois;
    Button btn_choice1, btn_choice2, btn_choice3;
    private ImageView back_button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_list);

        PlantName = (TextView) findViewById(R.id.PlantName);
        Minimum_Plant_temp = (TextView) findViewById(R.id.Minimum_Plant_temp);
        Maximum_Plant_temp = (TextView) findViewById(R.id.Maximum_Plant_temp);
        Minimum_Plant_humi = (TextView) findViewById(R.id.Minimum_Plant_humi);
        Maximum_Plant_humi = (TextView) findViewById(R.id.Maximum_Plant_humi);
        Plant_sun = (TextView) findViewById(R.id.Plant_sun);
        Plant_mois = (TextView) findViewById(R.id.Plant_mois);
        btn_choice1 = (Button) findViewById(R.id.btn_choice1);
        btn_choice2 = (Button) findViewById(R.id.btn_choice2);
        btn_choice3 = (Button) findViewById(R.id.btn_choice3);


        btn_choice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    //JSON 파일에 접근하는 코드
                    InputStream is = getAssets().open("PlantInformation.json");
                    int size = is.available();
                    byte[] buffer = new byte[size];
                    is.read(buffer);
                    is.close();
                    String json = new String(buffer, "UTF-8");


                    JSONObject jsonObject = new JSONObject(json);
                    JSONArray jsonArray = jsonObject.getJSONArray("Plant");

                    jsonObject = jsonArray.getJSONObject(0);
                    String p_name = jsonObject.getString("PlantName");
                    String p_min_temp = jsonObject.getString("Plant_Minimum_temp");
                    String p_max_temp = jsonObject.getString("Plant_Maximum_temp");
                    String p_min_humi = jsonObject.getString("Plant_Minimum_humi");
                    String p_max_humi = jsonObject.getString("Plant_Maximum_humi");
                    String p_sun = jsonObject.getString("Plant_sun");
                    String p_mois = jsonObject.getString("Plant_mois");

                    PlantName.setText(p_name);
                    Minimum_Plant_temp.setText(p_min_temp);
                    Maximum_Plant_temp.setText(p_max_temp);
                    Minimum_Plant_humi.setText(p_min_humi);
                    Maximum_Plant_humi.setText(p_max_humi);
                    Plant_sun.setText(p_sun);
                    Plant_mois.setText(p_mois);

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        btn_choice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    //JSON 파일에 접근하는 코드
                    InputStream is = getAssets().open("PlantInformation.json");
                    int size = is.available();
                    byte[] buffer = new byte[size];
                    is.read(buffer);
                    is.close();
                    String json = new String(buffer, "UTF-8");


                    JSONObject jsonObject = new JSONObject(json);
                    JSONArray jsonArray = jsonObject.getJSONArray("Plant");

                    jsonObject = jsonArray.getJSONObject(1);
                    String p_name = jsonObject.getString("PlantName");
                    String p_min_temp = jsonObject.getString("Plant_Minimum_temp");
                    String p_max_temp = jsonObject.getString("Plant_Maximum_temp");
                    String p_min_humi = jsonObject.getString("Plant_Minimum_humi");
                    String p_max_humi = jsonObject.getString("Plant_Maximum_humi");
                    String p_sun = jsonObject.getString("Plant_sun");
                    String p_mois = jsonObject.getString("Plant_mois");

                    PlantName.setText(p_name);
                    Minimum_Plant_temp.setText(p_min_temp);
                    Maximum_Plant_temp.setText(p_max_temp);
                    Minimum_Plant_humi.setText(p_min_humi);
                    Maximum_Plant_humi.setText(p_max_humi);
                    Plant_sun.setText(p_sun);
                    Plant_mois.setText(p_mois);

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        btn_choice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    //JSON 파일에 접근하는 코드
                    InputStream is = getAssets().open("PlantInformation.json");
                    int size = is.available();
                    byte[] buffer = new byte[size];
                    is.read(buffer);
                    is.close();
                    String json = new String(buffer, "UTF-8");


                    JSONObject jsonObject = new JSONObject(json);
                    JSONArray jsonArray = jsonObject.getJSONArray("Plant");

                    jsonObject = jsonArray.getJSONObject(2);
                    String p_name = jsonObject.getString("PlantName");
                    String p_min_temp = jsonObject.getString("Plant_Minimum_temp");
                    String p_max_temp = jsonObject.getString("Plant_Maximum_temp");
                    String p_min_humi = jsonObject.getString("Plant_Minimum_humi");
                    String p_max_humi = jsonObject.getString("Plant_Maximum_humi");
                    String p_sun = jsonObject.getString("Plant_sun");
                    String p_mois = jsonObject.getString("Plant_mois");

                    PlantName.setText(p_name);
                    Minimum_Plant_temp.setText(p_min_temp);
                    Maximum_Plant_temp.setText(p_max_temp);
                    Minimum_Plant_humi.setText(p_min_humi);
                    Maximum_Plant_humi.setText(p_max_humi);
                    Plant_sun.setText(p_sun);
                    Plant_mois.setText(p_mois);

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });


        back_button1 = findViewById(R.id.back_button1);
        back_button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Plant_list.this, MainActivity.class);
                startActivity(intent);

            }
        });
    }
}