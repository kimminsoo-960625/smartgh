package com.example.smartgh.main_menu_s;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.smartgh.MainActivity;
import com.example.smartgh.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class Biokdo extends AppCompatActivity {

    private Toolbar mToolbar;
    private boolean count;
    private ImageView back_button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biokdo);


        BarChart chart_mois = findViewById(R.id.chart_mois);

        ArrayList<BarEntry> bar_mois = new ArrayList<>();
        bar_mois.add(new BarEntry(7, 40));
        bar_mois.add(new BarEntry(6, 50));
        bar_mois.add(new BarEntry(5, 80));
        bar_mois.add(new BarEntry(4, 10));
        bar_mois.add(new BarEntry(3, 20));
        bar_mois.add(new BarEntry(2, 60));
        bar_mois.add(new BarEntry(1, 30));

        BarDataSet barDataSet_mois = new BarDataSet(bar_mois, "Moisture Average");
        barDataSet_mois.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet_mois.setValueTextColor(Color.BLACK);
        barDataSet_mois.setValueTextSize(16f);

        BarData barData_mois = new BarData(barDataSet_mois);

        chart_mois.setFitBars(true);
        chart_mois.setData(barData_mois);
        chart_mois.getDescription().setText("Moisture Chart");
        chart_mois.animateY(2000);

        back_button1 = findViewById(R.id.back_button1);
        back_button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Biokdo.this, MainActivity.class);
                startActivity(intent);

            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        switch (id){
            case android.R.id.home:
            {

                Intent resultIntent = new Intent();
                resultIntent.putExtra("count", count);
                setResult(RESULT_OK, resultIntent);
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
}