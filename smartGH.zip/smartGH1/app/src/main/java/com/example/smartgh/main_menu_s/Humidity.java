package com.example.smartgh.main_menu_s;


import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.smartgh.MainActivity;
import com.example.smartgh.R;
import com.example.smartgh.temperature_list.li_hum;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class Humidity extends AppCompatActivity {

    private TextView list_on1;
    private Toolbar mToolbar;
    private boolean count;
    private TextView txt_setting2;
    private ImageView back_button1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_humidity);




        txt_setting2 = findViewById(R.id.txt_setting2);
        list_on1 = findViewById(R.id.list_on1);
        list_on1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), li_hum.class);
                startActivity(intent);
            }
        });




        BarChart chart_humi = findViewById(R.id.chart_humi);

        ArrayList<BarEntry> bar_humi = new ArrayList<>();
        bar_humi.add(new BarEntry(7, 40));
        bar_humi.add(new BarEntry(6, 50));
        bar_humi.add(new BarEntry(5, 80));
        bar_humi.add(new BarEntry(4, 10));
        bar_humi.add(new BarEntry(3, 20));
        bar_humi.add(new BarEntry(2, 60));
        bar_humi.add(new BarEntry(1, 30));

        BarDataSet barDataSet_humi = new BarDataSet(bar_humi, "Humidity Average");
        barDataSet_humi.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet_humi.setValueTextColor(Color.BLACK);
        barDataSet_humi.setValueTextSize(16f);

        BarData barData_humi = new BarData(barDataSet_humi);

        chart_humi.setFitBars(true);
        chart_humi.setData(barData_humi);
        chart_humi.getDescription().setText("Humidity Chart");
        chart_humi.animateY(2000);

        back_button1 = findViewById(R.id.back_button1);
        back_button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Humidity.this, MainActivity.class);
                startActivity(intent);

            }
        });

    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        switch (id){
            case android.R.id.home:
            {

                Intent resultIntent = new Intent();
                resultIntent.putExtra("count", count);
                setResult(RESULT_OK, resultIntent);
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        Boolean switchState = sharedPreferences.getBoolean("autoSwitch_hum", false);
        String savedText = sharedPreferences.getString("hum1", "");
        if (switchState.equals(true)) {
            txt_setting2.setText("00℃");
        } else {
            txt_setting2.setText(savedText);
        }
    }

}