package com.example.smartgh.main_menu_s;


import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.smartgh.MainActivity;
import com.example.smartgh.R;
import com.example.smartgh.temperature_list.li_temp;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;



public class Temperature extends AppCompatActivity {


    private TextView list_on;
    private boolean count;
    private Toolbar mToolbar;
    private TextView txt_setting1;
    private ImageView back_button1;



    public static Object newinstance() {
        return null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature);





        txt_setting1 = findViewById(R.id.txt_setting1);
        list_on = findViewById(R.id.list_on);
        list_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), li_temp.class);
                startActivity(intent);
            }
        });


        BarChart chart_temp = findViewById(R.id.chart_temp);

        ArrayList<BarEntry> bar_temp = new ArrayList<>();
        bar_temp.add(new BarEntry(7, 40));
        bar_temp.add(new BarEntry(6, 50));
        bar_temp.add(new BarEntry(5, 80));
        bar_temp.add(new BarEntry(4, 10));
        bar_temp.add(new BarEntry(3, 20));
        bar_temp.add(new BarEntry(2, 60));
        bar_temp.add(new BarEntry(1, 30));

        BarDataSet barDataSet_temp = new BarDataSet(bar_temp, "Temperature Average");
        barDataSet_temp.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet_temp.setValueTextColor(Color.BLACK);
        barDataSet_temp.setValueTextSize(16f);

        BarData barData_temp = new BarData(barDataSet_temp);

        chart_temp.setFitBars(true);
        chart_temp.setData(barData_temp);
        chart_temp.getDescription().setText("Temperature Chart");
        chart_temp.animateY(2000);

        back_button1 = findViewById(R.id.back_button1);
        back_button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Temperature.this, MainActivity.class);
                startActivity(intent);

            }
        });

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case android.R.id.home: {

                Intent resultIntent = new Intent();
                resultIntent.putExtra("count", count);
                setResult(RESULT_OK, resultIntent);
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        Boolean switchState = sharedPreferences.getBoolean("autoSwitch", false);
        String savedText = sharedPreferences.getString("Temperature", "");
        if (switchState.equals(true)) {
            txt_setting1.setText("00℃");
        } else {
            txt_setting1.setText(savedText);
        }
    }
}
