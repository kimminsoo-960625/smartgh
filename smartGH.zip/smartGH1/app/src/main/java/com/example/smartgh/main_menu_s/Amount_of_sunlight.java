package com.example.smartgh.main_menu_s;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;


import com.example.smartgh.MainActivity;
import com.example.smartgh.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class Amount_of_sunlight extends AppCompatActivity {

    private Toolbar mToolbar;
    private boolean count;
    private ImageView back_button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amount_of_sunlight);

        back_button1 = findViewById(R.id.back_button1);
        back_button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Amount_of_sunlight.this, MainActivity.class);
                startActivity(intent);

            }
        });




        BarChart chart_sun = findViewById(R.id.chart_sun);

        ArrayList<BarEntry> bar_sun = new ArrayList<>();
        bar_sun.add(new BarEntry(7, 40));
        bar_sun.add(new BarEntry(6, 50));
        bar_sun.add(new BarEntry(5, 80));
        bar_sun.add(new BarEntry(4, 10));
        bar_sun.add(new BarEntry(3, 20));
        bar_sun.add(new BarEntry(2, 60));
        bar_sun.add(new BarEntry(1, 30));

        BarDataSet barDataSet_sun = new BarDataSet(bar_sun, "Sunshine Average");
        barDataSet_sun.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet_sun.setValueTextColor(Color.BLACK);
        barDataSet_sun.setValueTextSize(16f);

        BarData barData_sun = new BarData(barDataSet_sun);

        chart_sun.setFitBars(true);
        chart_sun.setData(barData_sun);
        chart_sun.getDescription().setText("Sunshine Chart");
        chart_sun.animateY(2000);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        switch (id){
            case android.R.id.home:
            {

                Intent resultIntent = new Intent();
                resultIntent.putExtra("count", count);
                setResult(RESULT_OK, resultIntent);
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
}
